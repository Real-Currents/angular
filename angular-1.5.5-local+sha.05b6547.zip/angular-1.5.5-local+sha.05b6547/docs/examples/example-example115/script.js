(function(angular) {
  'use strict';
angular.module('ngClickExample', ['ngTouch']);
})(window.angular);